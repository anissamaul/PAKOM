a = input('masukkan jumlah jenis barang :')
b = input('masukkan harga barang satuan : Rp.')
c = input('masukkan jumlah barang yang dibeli :')

total_belanja = (b*c)

  if total_belanja > 500000
    diskon = 0.025*total_belanja;
    disp('total yang harus dibayar');
    disp(diskon)
    disp('Anda mendapat discount 2,5%');
  else
    diskon = 0;
    disp('Maaf Anda tidak mendapat discount');
  end
