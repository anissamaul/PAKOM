function F = nilai(x)

  while x <= 200;
    fprintf('x=%d\n',x)
    F = 2*x+1
    if F >= 111;
      break
   end
x = x+1
end
