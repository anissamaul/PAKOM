function faktorial = faktorial(N)
x = 1;
for i=1:N
    x=x*i;
end
fprintf('hasil dari %d faktorial adalah %d', N,x);
disp(' ')
