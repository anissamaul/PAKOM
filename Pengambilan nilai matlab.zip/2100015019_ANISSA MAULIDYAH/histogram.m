function plot = histogram(x)
vektor = rand(x, 1);
hist(vektor)
end
