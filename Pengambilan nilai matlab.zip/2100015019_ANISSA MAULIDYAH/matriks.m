function matriks = matriks(N)

A=zeros(N);
A(:,:) = N;
a = zeros(N-2);
A(2:N-1,2:A-1)= a
