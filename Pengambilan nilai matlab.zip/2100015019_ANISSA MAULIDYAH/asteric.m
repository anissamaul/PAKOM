function segitiga_asteric = asteric(x)
  i = 0;
  while i <= x
    j = 0;
    while j < i
      fprintf('*');
      j = j+1;
    end
    fprintf('\n');
    i = i+1;
  end
  fprintf('\n');
end
