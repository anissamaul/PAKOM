function bilangan = cek_bilangan(x)

if x < 0
  disp('x merupakan bilangan negatif');
elseif x > 0
  disp('x merupakan bilangan positif');
else
  disp('x merupakan bilangan samadengan 0 atau netral');
  end
