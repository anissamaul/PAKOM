n = 5;
m=zeros(n);
m(:,:) = n;
a = zeros(N-2);
m(2:n-1,2:n-1)= a
