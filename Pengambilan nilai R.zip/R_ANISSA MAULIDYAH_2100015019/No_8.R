faktorial = function(N) {
  N = as.integer(N);
  x = 1;
  for (i in 1:N) {
    x = x*i
    print(x)
  }
  print(paste("Hasil dari",N,"faktorial adalah", x))
}
faktorial(4)
