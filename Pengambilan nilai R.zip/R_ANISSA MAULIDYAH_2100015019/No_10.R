Fungsi = function(a) {
  for (x in 1:a) {
    n = 2*x+1
    if (n > 111){
      break
    }
    print(paste("F(x) : ", n))
  }
}
Fungsi(111)
