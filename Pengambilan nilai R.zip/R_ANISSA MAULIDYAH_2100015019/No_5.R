x = readline(prompt = "masukkan angka : ");
if (x < 0) {
  print("bilangan negatif")
} else if (x > 0) {
  print("bilangan positif")
} else {
  print("bilangan samadengan nol atau netral")
}
