A <- matrix(1,5,5)
N <- 5*A

for (i in 2:4) {
  for (j in 2:4) {
    N[i,j] = 0
  }
};N
