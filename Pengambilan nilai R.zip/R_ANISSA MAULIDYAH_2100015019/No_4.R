vektor = function(A, N) {
  m = matrix(1, N, N)
  n = A*m
  for (i in 3:N-1) {
    for (j in 3:N-1) {
      n[i,j] = 0
    }
  };n
}
vektor(5,5)
