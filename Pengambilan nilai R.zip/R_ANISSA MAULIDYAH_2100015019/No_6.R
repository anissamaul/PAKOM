a = readline("a = ") #jumlah jenis barang
b = readline("b = ") #harga satuan barang yang dibeli
c = readline("c = ") #jumlah barang yang dibeli
B = as.numeric(b)
C = as.numeric(c)
total = (B*C)
total_bayar = as.numeric(total)

if (total_belanja > 500000) {
  print("SELAMAT ANDA MENDAPATKAN DISCOUNT 2,5%")
  diskon = total_belanja*0.025
  total_bayar = total_belanja-diskon
} else {
  print("MAAF, ANDA TIDAK MENDAPATKAN DISCOUNT")
  diskon = 0
  total_bayar = total_belanja-diskon
}
print(diskon)
print(total_bayar)
