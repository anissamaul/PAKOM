segitiga_asteric = function(x) {
  i = 1
  while (i <= x) {
    j = 1
    while (j <= i) {
      cat("*")
      j = j+1
    }
    i = i+1
    cat("\n")
  }
}
segitiga_asteric(4)
