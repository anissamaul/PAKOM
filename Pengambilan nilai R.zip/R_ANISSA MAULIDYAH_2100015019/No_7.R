plot_histogram = function(x) {
  N = as.integer(x);
  vektor = seq(from=0, to=N)
  hist(vektor)
}
plot_histogram(5)
