a = 999
b = 3
n = 100

U = a+(n-1)*b

X = seq(a,U, by=b)
X
