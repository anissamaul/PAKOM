function [nilai] = fungsi1(x,y)
  nilai = round(x)
  nilai = round(y)
