x = [-2:3:2];
y = x.^2+4*x+16;
plot (x, y)
grid
