a = input('masukkan harga buku:')
m = input('masukkan jumlah buku:')
b = input('masukkan harga pensil:')
n = input('masukkan jumlah pensil:')
c = input('masukkan harga penggaris:')
o = input('masukkan jumlah penggaris:')

total = (a*m + b*n + c*o);
disp('total pembelian:')
disp(total)

