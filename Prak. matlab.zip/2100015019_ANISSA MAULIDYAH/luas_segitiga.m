function [luas_segitiga] = luas_segitiga(a,t)
  % Dokumentasi :
  % Function untuk menghitung luas segitiga dari input panjang alas dan tinggi segitiga
  % Input : a : panjang alas segitiga,
  %         t : tinggi segitiga
  % Output : luas_segitiga : luas segitiga
  % ---------------------------------------------------------------------------------------
  a = input('panjang alas = ');                      % Panjang alas segitiga
  t = input('tinggi = ');                            % Tinggi segitiga
  luas_segitiga = a*t/2;                             % Luas segitiga
  end
