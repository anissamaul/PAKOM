a = input('masukkan harga buku = Rp.')
m = input('masukkan jumlah buku =')
b = input('masukkan harga pensil = Rp.')
n = input('masukkan jumlah pensil =')
c = input('masukkan harga penggaris = Rp.')
o = input('masukkan jumlah penggaris =')

total1 = (a*m + b*n + c*o)
diskon = 5/100*(total1);
total= (total1-diskon)

keuntungan_buku = (a*m*10/100)
keuntungan_pensil = (b*n*10/100)
keuntungan_penggaris = (c*o*10/100)
