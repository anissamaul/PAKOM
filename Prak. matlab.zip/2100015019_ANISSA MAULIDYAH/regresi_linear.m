function [rata_rata_X, rata_rata_Y, b1, b0, regresi] = regresi_linear(X,Y)
  % Dokumentasi :
  % Function untuk menghitung parameter b0 dan b1 pada persamaan regresi linear
  % Input  : Vektor X
  %          Vektor Y
  % Output : rata_rata_X,
  %          rata_rata_Y,
  %          b1,
  %          b0
  % ----------------------------------------------------------------------------
  n = length(X)                                                             % Panjang vektor X
  m = length(Y)                                                             % Panjang vektor Y
  rata_rata_X = sum(X)/n                                                    % Rata-rata X
  rata_rata_Y = sum(Y)/m                                                    % Rata-rata Y
  b1 = ((sum(X-rata_rata_X))*(sum(Y-rata_rata_Y)))/sum(X-rata_rata_X)^2     % Nilai b1
  b0 = rata_rata_Y-b1.*rata_rata_X                                          % Nilai b0
  regresi = ['Y =', num2str(b0),'+', num2str(b1), 'X']
  end
