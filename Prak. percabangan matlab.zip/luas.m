function luas_tanah = luas(panjang,lebar,tinggi,r)
  disp("Menghitung luas tanah")
  disp("1. Persegi/persegi panjang")
  disp("2. Segitiga")
  disp("3. Lingkaran")
  disp("\n")
  pil=input('masukkan pilihan untuk menghitung luas tanah: ')
  switch pil
    case 1
      disp("luas tanah persegi/persegi panjang")
      luas_tanah=panjang*lebar;
      luas_tanah
    case 2
      disp("luas tanah segitiga")
      luas_tanah=1/2*panjang*lebar;
      luas_tanah
    case 3
      disp("luas tanah lingkaran");
      luas_tanah=pi*r^2
    end
 end

