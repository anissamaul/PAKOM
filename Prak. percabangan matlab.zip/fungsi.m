function y = fungsi(x)
  if x < -1
       y = 1;
    fprintf('cetak fungsi %d \n', y);
   else
     if x >= -1 && x <= 2
          y = 1;
     fprintf('cetak fungsi %d \n', y);
     else
        y = 4
        fprintf('cetak fungsi %d \n', y);
     end
 end
